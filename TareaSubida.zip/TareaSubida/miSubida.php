<html>
<head>
<title>Subida de archivos </title>
<meta charset="UTF-8">
</head>
<?php

	$mensaje = "";
    //Si no se encuentra ruta
	if (!isset($_REQUEST['directorio'])) {
    	$mensaje .="ERROR: No se indica la ruta del directorio.<br/>";
        $error = true;
    }else{
    //Si no se selecciona archivo
        if ($_FILES['archivo1']["name"] == "" and $_FILES['archivo2']["name"] == "") {
            $mensaje .="ERROR: No hay ningun archivo seleccionado.<br/>";
            $error = true;
        }
        else{
            $error = false;
            $directorioSubida  =   $_REQUEST['directorio'];
            $nombres  = scandir($directorioSubida);
            $mensaje .= 'Intentando subir el archivo... ' . ' <br/>';

            if($_FILES['archivo1']["name"] != "") {
                $tipoFichero1      =   $_FILES['archivo1']['type'];
                $nombreFichero1    =   $_FILES['archivo1']['name'];
                $tamanioFichero1   =   $_FILES['archivo1']['size'];
                $temporalFichero1  =   $_FILES['archivo1']['tmp_name'];
                $existe1 = true;
                $mensaje .= "<span style=color:blue;>- Nombre fichero 1: $nombreFichero1" . ' </span><br/>';
                $mensaje .= '<span style=color:blue;>- Tamaño del fichero 1: ' . ($tamanioFichero1 / 1024) . ' KB </span><br/>';
                $mensaje .= "<span style=color:blue;>- Tipo del fichero 1: $tipoFichero1" . ' </span><br/>' ;
                $mensaje .= "<span style=color:blue;>- Nombre archivo temporal 1: $temporalFichero1" . ' </span><br/>';
            }else{
                $existe1 = false;
            }

            if($_FILES['archivo2']["name"] != "") {
                $tipoFichero2      =   $_FILES['archivo2']['type'];
                $nombreFichero2    =   $_FILES['archivo2']['name'];
                $tamanioFichero2   =   $_FILES['archivo2']['size'];
                $temporalFichero2  =   $_FILES['archivo2']['tmp_name'];
                $existe2 = true;
                $mensaje .= "<span style=color:red;>- Nombre fichero 2: $nombreFichero2" . ' </span><br/>';
                $mensaje .= '<span style=color:red;>- Tamaño del fichero 2: ' . ($tamanioFichero2 / 1024) . ' KB </span><br/>';
                $mensaje .= "<span style=color:red;>- Tipo del fichero 2: $tipoFichero2" . ' </span><br/>' ;
                $mensaje .= "<span style=color:red;>- Nombre archivo temporal 2: $temporalFichero2" . ' </span><br/><br/>';
            }else{
                $existe2 = false;
            }

            $mensaje .= '<hr /></br>';
            //Comienza el funcionamiento
            if ($existe1 == true and $existe2 == true) {
                if ($tamanioFichero1 > 200000 or $tamanioFichero2 > 200000) {
                    $mensaje .= "ERROR: Ha sido superada la capacidad maxima del fichero (200 KB).<br/>";
                    $error = true;
                }
                if ($tamanioFichero1 + $tamanioFichero2 > 300000) {
                    $mensaje .= "ERROR: Ha sido superada la capacidad máxima del los fichero conjuntos (300 KB).<br/>";
                    $error = true;
                }
                for ($i=0; $i < count($nombres); $i++) { 
                    if($nombreFichero1 == $nombres[$i] or $nombreFichero2 == $nombres[$i]) {
                        $mensaje .= "ERROR: El nombre del archivo ya existe.<br/>";
                        $error = true;
                        break;
                    }
                }   
                $extension1 = explode(".", $nombreFichero1);
                $ext1 = $extension1[1];
                $extension2 = explode(".", $nombreFichero2);
                $ext2 = $extension2[1];
                if (($ext1 != 'jpg' and $ext1 != 'png') or ($ext2 != 'jpg' and $ext2 != 'png')) {
                    $mensaje .= "ERROR: Extensión no válida.<br/>";  
                    $error = true;
                }
                if (! is_dir($directorioSubida) or ! is_writable ($directorioSubida)) { 
                        $mensaje .= "ERROR: No tienes los permisos o no es directorio la ruta seleccionada.<br/>";  
                        $error = true;
                    }else{
                        $mensaje .= '<br /><hr />';
                        if (($error != true) and move_uploaded_file($temporalFichero1,  $directorioSubida .'/'. $nombreFichero1) == true){
                            $mensaje .= '</br><span style=font-weight:bold;>RESULT: Archivo guardado en: ' . $directorioSubida .'/'. $nombreFichero1 . ' </span><br/>';
                        }
                         else{
                            $mensaje .= '</br><span style=font-weight:bold;>RESULT: Archivo 1 no guardado correctamente </span><br/>';
                        }
                        if (($error != true) and move_uploaded_file($temporalFichero2,  $directorioSubida .'/'. $nombreFichero2) == true) {
                            $mensaje .= '<span style=font-weight:bold;>RESULT: Archivo guardado en: ' . $directorioSubida .'/'. $nombreFichero2 . ' </span><br/>';
                        }else{
                            $mensaje .= '<span style=font-weight:bold;>RESULT: Archivo 2 no guardado correctamente </span><br/>';
                    }
                }
            }else{
                if ($existe1 == true){
                    if ($tamanioFichero1 > 200000){
                        $mensaje .= "ERROR: Ha sido superada la capacidad maxima del fichero (200 KB).<br/>";
                        $error = true;
                    }
                
                    for ($i=0; $i < count($nombres); $i++) { 
                        if($nombreFichero1 == $nombres[$i]) {
                            $mensaje .= "ERROR: El nombre del archivo ya existe.<br/>";
                            $error = true;
                            break;
                        }
                    }
                    $extension1 = explode(".", $nombreFichero1);
                    $ext1 = $extension1[1];
                    if ($ext1 != 'jpg' and $ext1 != 'png') {
                        $mensaje .= "ERROR: Extensian no valida.<br/>";  
                        $error = true;
                    }


                    if (! is_dir($directorioSubida) or ! is_writable ($directorioSubida)) { 
                            $mensaje .= "ERROR: No tienes los permisos o no es directorio la ruta seleccionada.<br/>";  
                            $error = true;
                    }else{
                        $mensaje .= '<br /><hr />';
                        if (($error != true) and move_uploaded_file($temporalFichero1,  $directorioSubida .'/'. $nombreFichero1) == true){
                            $mensaje .= '</br><span style=font-weight:bold;>RESULT: Archivo guardado en: ' . $directorioSubida .'/'. $nombreFichero1 . ' </span><br/>';
                        }
                        else{
                            $mensaje .= '</br><span style=font-weight:bold;>RESULT: Archivo 1 no guardado correctamente </span><br/>';
                        }
                    }
                }
                if ($existe2 == true){
                    if($tamanioFichero2 > 200000){
                        $mensaje .= "ERROR: Ha sido superada la capacidad maxima del fichero (200 KB).<br/>";
                        $error = true;
                    }
                    for ($i=0; $i < count($nombres); $i++) { 
                        if($nombreFichero2 == $nombres[$i]) {
                            $mensaje .= "ERROR: El nombre del archivo ya existe.<br/>";
                            $error = true;
                            break;
                        }
                    }
                    $extension2 = explode(".", $nombreFichero2);
                    $ext2 = $extension2[1];
                    if ($ext2 != 'jpg' and $ext2 != 'png') {
                        $mensaje .= "ERROR: Extension no valida.<br/>";  
                        $error = true;
                    }

                    if (! is_dir($directorioSubida) or ! is_writable ($directorioSubida)) { 
                            $mensaje .= "ERROR: No tienes los permisos o no es directorio la ruta seleccionada.<br/>";  
                            $error = true;
                    }else{
                        $mensaje .= '<br /><hr />';
                        if (($error != true) and move_uploaded_file($temporalFichero2,  $directorioSubida .'/'. $nombreFichero2) == true){
                            $mensaje .= '</br><span style=font-weight:bold;>RESULT: Archivo guardado en: ' . $directorioSubida .'/'. $nombreFichero2 . ' </span><br/>';
                        }
                        else{
                                $mensaje .= '</br><span style=font-weight:bold;>RESULT: Archivo 2 no guardado correctamente </span><br/>';
                        }
                    }
                }
            }
        }
    } 

?>


<body>
<?php echo " Bienvenido <b>".$_REQUEST['nombre']."</b><br>"
?>
<?php echo $mensaje; 
?>
<br/>
	<a href="subirfichero.html"><hr><br>Volver a la página de subida</a>
</body>
</html>